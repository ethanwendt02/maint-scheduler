DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "maint",
        "USER": "maint",
        "PASSWORD": "maint",
        "HOST": "db",
        "PORT": 5432,
    }
}
