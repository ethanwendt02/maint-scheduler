from celery import shared_task
from django.utils import timezone
from dateutil.relativedelta import relativedelta
from apps.fleet.models import Robot, Site
from apps.policies.models import MaintenancePolicy
from .models import WorkOrder




def robot_matches_scope(robot, scope: dict) -> bool:
model_ok = scope.get("model") in (None, "*", robot.model)
site_ok = scope.get("site") in (None, "*", (robot.site.name if robot.site else None))
return model_ok and site_ok


@shared_task
def generate_work_orders():
now = timezone.now()
for pol in MaintenancePolicy.objects.all():
if pol.type != "time" or not pol.interval_days:
continue
# naive example: apply to all robots matching scope
for robot in Robot.objects.select_related("site").all():
if not robot_matches_scope(robot, pol.scope):
continue
due_by = now + relativedelta(days=+pol.interval_days)
# skip if an open WO from this policy exists within window
window_start = now - relativedelta(days=pol.window_days)
exists = WorkOrder.objects.filter(robot=robot, policy=pol, status__in=["planned","assigned"]) \
.filter(due_by__gte=window_start).exists()
if exists:
continue
WorkOrder.objects.create(
robot=robot, site=robot.site, policy=pol, type="PM",
due_by=due_by, priority=pol.priority,
)