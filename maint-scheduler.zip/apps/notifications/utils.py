import os, requests
from typing import List


SLACK_WEBHOOK = os.getenv("SLACK_WEBHOOK")


def send_slack(channel: str, text: str):
if not SLACK_WEBHOOK:
return
requests.post(SLACK_WEBHOOK, json={"text": f"[{channel}] {text}"})


def send_email(recipients: List[str], subject: str, body: str):
# stub: integrate SES/SendGrid; for dev just print
print("EMAIL:", recipients, subject, body)