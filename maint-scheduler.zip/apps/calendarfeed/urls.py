from django.urls import path
from .views import feed
urlpatterns = [path("<str:token>.ics", feed)]